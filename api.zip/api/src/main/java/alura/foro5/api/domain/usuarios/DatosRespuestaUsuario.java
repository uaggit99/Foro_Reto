package alura.foro5.api.domain.usuarios;

public record DatosRespuestaUsuario(Long id, String clave, String login, String email) {
}

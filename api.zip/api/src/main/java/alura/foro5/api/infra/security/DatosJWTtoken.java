package alura.foro5.api.infra.security;

public record DatosJWTtoken(String jwTtoken) {
}

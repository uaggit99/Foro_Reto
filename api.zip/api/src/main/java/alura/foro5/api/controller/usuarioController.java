package alura.foro5.api.controller;

import alura.foro5.api.domain.usuarios.*;
import alura.foro5.api.infra.security.MailService;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;
;import java.net.URI;

@RestController
@RequestMapping("/usuario")
public class usuarioController {

    @Autowired
    private UsuarioLogRepository usuarioRepository;
    @Autowired
    private MailService mailService;

    private String  Email;


    @PostMapping
    public ResponseEntity<DatosRespuestaUsuario> registrousuario(@RequestBody @Valid DatosregistroUsuario datosregistroUsuario, UriComponentsBuilder uriComponentsBuilder){
         Email= datosregistroUsuario.clave();
         System.out.println("valor  buscado"+Email);
         UsuarioLog usuarioLog = usuarioRepository.save(new UsuarioLog(datosregistroUsuario));

        if(usuarioLog!=null){
            mailService.envioEmail(usuarioLog.getEmail(),usuarioLog.getLogin(),Email);
        }
        DatosRespuestaUsuario datosRespuestaUsuario = new DatosRespuestaUsuario(usuarioLog.getId(),usuarioLog.getLogin(),usuarioLog.getClave(), usuarioLog.getEmail());
        URI url = uriComponentsBuilder.path("/usuario/{id}").buildAndExpand(usuarioLog.getId()).toUri();
        return ResponseEntity.created(url).body(datosRespuestaUsuario);

    }

}

package alura.foro5.api.domain.topico;

public enum StatusTopico {
    NO_RESPONDIDO,
    NO_SOLUCIONADO,
    SOLUCIONADO,
    CERRADO
}
